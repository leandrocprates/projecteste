/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author leandro
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

public class Main {

    public static void main (String args[])
    {
        Conta conta[]=new Conta[3];
        Conta conta2=new Conta();

        conta[0]=new Conta();
        conta[1]=new Conta();
        conta[2]=new Conta();

        conta[0].setNumero_Conta("0");
        conta[0].setNome_Usuario("Conta1");
        conta[0].setSaldo(10);
        
        conta[1].setNumero_Conta("1");
        conta[1].setNome_Usuario("Conta2");
        conta[1].setSaldo(20);

        conta[2].setNumero_Conta("2");
        conta[2].setNome_Usuario("Conta3");
        conta[2].setSaldo(30);
        
        List<Conta> lista=new ArrayList<Conta>();
        lista.add(conta[0]);
        lista.add(conta[1]);
        lista.add(conta[2]);

        for ( int i=0 ; i< 3 ; i++ )
        {
           conta2 = (Conta )lista.get(i);
           System.out.println( "Numero Conta: " + conta2.getNumero_Conta() );
           System.out.println( "Nome Usuario: " + conta2.getNome_Usuario() );
           System.out.println( "Saldo : " + conta2.getSaldo() );
        }

    }

}
