/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author leandro
 */
public class Conta {

    private String Numero_Conta;
    private String Nome_Usuario;
    private double Saldo;


    public void setNumero_Conta(String Numero_Conta){
        this.Numero_Conta=Numero_Conta;
    }

    public void setNome_Usuario(String Nome_Usuario){
        this.Nome_Usuario=Nome_Usuario;
    }

    public void setSaldo(double Saldo){
        this.Saldo=Saldo;
    }

    public String getNumero_Conta(){
        return this.Numero_Conta;
    }

    public String getNome_Usuario(){
        return this.Nome_Usuario;
    }

    public double getSaldo(){
        return this.Saldo;
    }

}

