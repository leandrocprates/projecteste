/* 
 * File:   ordena.c
 * Author: leandro
 *
 * Created on 10 de Novembro de 2009, 23:55
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
 * 
 */
int main(int argc, char** argv) {

    int vet[8];
    int temp=0;
    char str[20];
    char temp_char[10];
    int j=0;

    FILE *f1= fopen("entrada.txt" , "r");

    while (!feof(f1))
    {
        fgets(temp_char,10,f1);
        vet[j++]=atoi(temp_char);
    }


    for ( int t=1 ; t<8 ; t++ )
    {
        for ( int i=0 ; i< 8-t ; i++ )
        {
            if ( vet[i]>vet[i+1])
            {
                temp=vet[i+1];
                vet[i+1]=vet[i];
                vet[i]=temp;
            }
        }
    }


    FILE *f2= fopen("saida_ordenada.txt" , "w");

    for ( int i=0 ; i< 8 ; i++ )
    {
        memset(str,'\0',sizeof(str));
        sprintf(str,"%d\n",vet[i]);
        fputs ( str, f2);
    }

    fclose(f2);
    

    return (EXIT_SUCCESS);
}

