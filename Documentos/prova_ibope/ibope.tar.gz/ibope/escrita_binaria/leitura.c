/* 
 * File:   leitura.c
 * Author: leandro
 *
 * Created on 10 de Novembro de 2009, 22:21
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    char str[80];
    unsigned char leitura;
    int acumula=0;
    int media=0;
    int pontos=0;
    FILE *fsc ;
    int kk;
    //Ler 100 arquivos de um diretorio
    //for (kk=0;kk<100;kk++)
    //{
        /*Imprimir em str o nome concatenado pela variavel path alem da
         * constante ID e o contador dado pela variavel kk  */

        /*patch  - nao existente
         * ID  - nao existente
         * */
        sprintf(str, "%s",  "arquivo.txt");

        if ((fsc=fopen(str,"wb") )==0){
            //Imprimir a informacao ao usuario a informacao de erro
            printf("Erro ao abrir o arquivo %s", str );
        }
        else {


                fwrite("o",1,20,fsc);

            // Com o arquivo aberto leia os dados binarios
            //while(!feof(fsc)){
                //Leitura de 8 bits
                fread(&leitura,1,1,fsc);
            //    pontos++;
                
                // Acumule os dados na variavel acumulada
            //    acumula+=leitura;
            //}
            // Calcule a media dos valores lidos
            //media=(acumula/pontos);

            /*Imprima a media calculada, a quantidade de pontos lidos e o numero
             * do arquivo tambem , sendo que a media deve ser impressa em hexadecimal
             * e a quantidade de pontos em decimal , todos com
             * separacao com TAB e LINE FEED ao final da impressao */
            //printf("Media [%x] \t\n Pontos [%d] \t\n kk [%d] \n" , media , pontos , kk);

        }

        fclose(fsc);

    //}

    return (EXIT_SUCCESS);
}

