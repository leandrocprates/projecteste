package com.sample.dao;

import java.util.List;

import com.sample.model.Pessoa;

public interface PessoaDao {
	void save(Pessoa pessoa);
	void delete(Integer id);
	Pessoa getById(Integer id);
	List<Pessoa> findAll();	
}
