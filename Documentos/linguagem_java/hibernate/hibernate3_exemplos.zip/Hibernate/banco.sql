CREATE TABLE Pessoa (
  id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255) NULL,
  email VARCHAR(255) NULL,
  telefone VARCHAR(255) NULL,
  PRIMARY KEY(id)
)
TYPE=InnoDB;

CREATE TABLE Curso (
  id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255) NULL,
  descricao TEXT NULL,
  PRIMARY KEY(id)
)
TYPE=InnoDB;

CREATE TABLE Professor (
  Pessoa_id INTEGER UNSIGNED NOT NULL,
  titulo VARCHAR(255) NULL,
  PRIMARY KEY(Pessoa_id),
  INDEX Professor_FKIndex1(Pessoa_id),
  FOREIGN KEY(Pessoa_id)
    REFERENCES Pessoa(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;

CREATE TABLE Endereco (
  Pessoa_id INTEGER UNSIGNED NOT NULL,
  rua VARCHAR(255) NULL,
  numero INTEGER UNSIGNED NULL,
  bairro VARCHAR(255) NULL,
  estado VARCHAR(255) NULL,
  complemento TEXT NULL,
  cep VARCHAR(255) NULL,
  cidade VARCHAR(255) NULL,
  PRIMARY KEY(Pessoa_id),
  INDEX Endereco_FKIndex1(Pessoa_id),
  FOREIGN KEY(Pessoa_id)
    REFERENCES Pessoa(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;

CREATE TABLE Aluno (
  Pessoa_id INTEGER UNSIGNED NOT NULL,
  matricula VARCHAR(255) NULL,
  PRIMARY KEY(Pessoa_id),
  INDEX Aluno_FKIndex1(Pessoa_id),
  FOREIGN KEY(Pessoa_id)
    REFERENCES Pessoa(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;

CREATE TABLE Disciplina (
  id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  Curso_id INTEGER UNSIGNED NOT NULL,
  nome VARCHAR(255) NULL,
  ementa TEXT NULL,
  PRIMARY KEY(id),
  INDEX Disciplina_FKIndex1(Curso_id),
  FOREIGN KEY(Curso_id)
    REFERENCES Curso(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;

CREATE TABLE Turma (
  id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  Disciplina_id INTEGER UNSIGNED NOT NULL,
  Professor_Pessoa_id INTEGER UNSIGNED NOT NULL,
  nome VARCHAR(255) NULL,
  PRIMARY KEY(id),
  INDEX Turma_FKIndex1(Professor_Pessoa_id),
  INDEX Turma_FKIndex2(Disciplina_id),
  FOREIGN KEY(Professor_Pessoa_id)
    REFERENCES Professor(Pessoa_id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Disciplina_id)
    REFERENCES Disciplina(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;

CREATE TABLE Turma_has_Aluno (
  Turma_id INTEGER UNSIGNED NOT NULL,
  Aluno_Pessoa_id INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(Turma_id, Aluno_Pessoa_id),
  INDEX Turma_has_Aluno_FKIndex1(Turma_id),
  INDEX Turma_has_Aluno_FKIndex2(Aluno_Pessoa_id),
  FOREIGN KEY(Turma_id)
    REFERENCES Turma(id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Aluno_Pessoa_id)
    REFERENCES Aluno(Pessoa_id)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
)
TYPE=InnoDB;


