package br.com.guj.hibernateTransaction.example;

import java.util.Scanner;

import br.com.guj.hibernateTransaction.HibernateInterceptorAnnotation;
import br.com.guj.hibernateTransaction.TransactionClass;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class Main {
	public static void main(String[] args) throws Exception {
		try {
			Banco banco = (Banco) TransactionClass.create(Banco.class,
					HibernateInterceptorAnnotation.class);
	
			Scanner teclado = new Scanner(System.in);
			
			System.out.println("Qual � o ID do pagador?");
			Cliente pagador = banco.getCliente(new Long(teclado.next()));
			
			System.out.println("Qual � o ID do favorecido?");
			Cliente favorecido = banco.getCliente(new Long(teclado.next()));
			
			System.out.println("Qual � o valor a ser transferido?");
			Double valor = new Double(teclado.next());
			
			//Chamada a opera��o transacional2
			banco.efetuarTransferencia(pagador, favorecido, valor);
			
			System.out.println("Transfer�ncia efetuada com sucesso!");
			
		} catch (Exception e) {
			System.out.println("Transa��o n�o foi efetuada. Confira a stackTrace:");
			e.printStackTrace();
		}
	}
}
