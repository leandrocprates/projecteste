package br.com.guj.hibernateTransaction;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class HibernateHelper {
	private static final SessionFactory sessionFactory;
	private static final ThreadLocal sessionThread = new ThreadLocal();
	private static final ThreadLocal transactionThread = new ThreadLocal();

	static {
		try {
			sessionFactory = new Configuration().configure()
					.buildSessionFactory();
		} catch (RuntimeException e) {
			e.printStackTrace();
			throw e;
		}
	}

	public static Session currentSession() {
		if (sessionThread.get() == null) {
			Session session = sessionFactory.openSession();
			sessionThread.set(session);
		}
		return (Session) sessionThread.get();
	}

	private static void closeSession() {
		Session session = (Session) sessionThread.get();
		if (session != null) {
			session.close();
		}
		sessionThread.set(null);
	}

	static void beginTransaction() {
		if (transactionThread.get() == null) {
			Transaction transaction = currentSession().beginTransaction();
			transactionThread.set(transaction);
		}
	}

	static void commitTransaction() {
		Transaction transaction = (Transaction) transactionThread.get();
		if (transaction != null && !transaction.wasCommitted()
				&& !transaction.wasRolledBack()) {
			transaction.commit();
			transactionThread.set(null);
		}
		closeSession();
	}

	static void rollbackTransaction() {
		Transaction transaction = (Transaction) transactionThread.get();
		if (transaction != null && !transaction.wasCommitted()
				&& !transaction.wasRolledBack()) {
			transaction.rollback();
			transactionThread.set(null);
		}
		closeSession();
	}
}
