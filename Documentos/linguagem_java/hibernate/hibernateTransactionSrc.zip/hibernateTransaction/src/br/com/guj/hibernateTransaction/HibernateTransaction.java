package br.com.guj.hibernateTransaction;

import java.lang.annotation.*;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface HibernateTransaction {}
