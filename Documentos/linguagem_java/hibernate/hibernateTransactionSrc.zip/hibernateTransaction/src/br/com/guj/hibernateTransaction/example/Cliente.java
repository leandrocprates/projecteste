package br.com.guj.hibernateTransaction.example;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class Cliente {
	private Long id;
	private String nome, senha;
	private Double saldo;
	
	public Cliente() {}
	
	public Cliente(String nome, String senha, Double saldo) {
		this.nome  = nome;
		this.senha = senha;
		this.saldo = saldo;
	}
	
	public void transfere(Cliente destino, Double valor) throws Exception {
		if (valor <= 0) {
			throw new Exception("Valor inv�lido: menor que zero");
		}
		if (this.getSaldo() < valor) {
			throw new Exception("N�o possui saldo suficiente");
		}
		
		this.setSaldo(this.getSaldo() - valor);
		destino.setSaldo(destino.getSaldo() + valor);
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
}
