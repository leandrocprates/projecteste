package br.com.guj.hibernateTransaction.example;

import java.io.Serializable;
import java.util.List;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public interface ClienteDAO {
	public void salvaCliente(Cliente cliente) throws Exception;
	public void removeCliente(Cliente cliente) throws Exception;
	public void atualizaCliente(Cliente cliente) throws Exception;
	public Cliente getCliente(Serializable id) throws Exception;
	public List<Cliente> listaClientes() throws Exception;
}