package br.com.guj.hibernateTransaction;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class HibernateInterceptorAnnotation extends HibernateInterceptor {
	public boolean isTransactional(Object object, Method method) throws Exception {
		Annotation annotation = method.getAnnotation(HibernateTransaction.class);
		return annotation == null ? false : true;
	}
}
