package br.com.guj.hibernateTransaction.example;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class DAOFactory {
	public static ClienteDAO createClienteDAO() {
		return new HibernateClienteDAO();
	}
}
