package br.com.guj.hibernateTransaction;

import java.lang.reflect.Method;
import net.sf.cglib.proxy.*;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public abstract class HibernateInterceptor implements MethodInterceptor {

	public Object intercept(Object object, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
		Object result = null;
		if (isTransactional(object, method)) {
			HibernateHelper.beginTransaction();
		}
		try {
			result = methodProxy.invokeSuper(object, args);
			HibernateHelper.commitTransaction();
		} catch (Exception e) {
			HibernateHelper.rollbackTransaction();
			throw e;
		} 
		return result;
	}
	
	public abstract boolean isTransactional(Object object, Method method) throws Exception;
}
