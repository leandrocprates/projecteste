package br.com.guj.hibernateTransaction.example;

import java.io.Serializable;

import br.com.guj.hibernateTransaction.HibernateTransaction;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class Banco {
	
	@HibernateTransaction
	public void efetuarTransferencia(Cliente pagador, Cliente favorecido,
			Double valor) throws Exception {
		pagador.transfere(favorecido, valor);
		ClienteDAO dao = DAOFactory.createClienteDAO();
		dao.atualizaCliente(pagador);
		dao.atualizaCliente(favorecido);
	}
	
	//Por ser um select, n�o precisa de transa��o
	public Cliente getCliente(Serializable id) throws Exception {
		return DAOFactory.createClienteDAO().getCliente(id);
	}
}
