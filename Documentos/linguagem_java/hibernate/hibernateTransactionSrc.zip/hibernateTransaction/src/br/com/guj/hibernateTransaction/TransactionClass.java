package br.com.guj.hibernateTransaction;

import net.sf.cglib.proxy.Enhancer;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class TransactionClass {
	public static Object create(Class beanClass, Class interceptorClass) throws Exception {
		HibernateInterceptor interceptor = (HibernateInterceptor)interceptorClass.newInstance();
		Object object = Enhancer.create(beanClass, interceptor);
		return object;
	}
}
