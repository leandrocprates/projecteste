package br.com.guj.hibernateTransaction.example;

import java.io.Serializable;
import java.util.List;

import br.com.guj.hibernateTransaction.HibernateHelper;

/**
 * @author Davi Luan Carneiro (daviluan@gmail.com)
 */
public class HibernateClienteDAO implements ClienteDAO {

	public void salvaCliente(Cliente cliente) throws Exception {
		HibernateHelper.currentSession().save(cliente);		
	}

	public void removeCliente(Cliente cliente) throws Exception {
		HibernateHelper.currentSession().delete(cliente);	
	}

	public void atualizaCliente(Cliente cliente) throws Exception {
		HibernateHelper.currentSession().update(cliente);		
	}

	public Cliente getCliente(Serializable id) throws Exception {
		return (Cliente)HibernateHelper.currentSession().get(Cliente.class, id);
	}
	
	public List<Cliente> listaClientes() throws Exception {
		return HibernateHelper.currentSession().createCriteria(Cliente.class).list();
	}
}
