import java.io.*;
import java.net.*;

public class ClienteDatagrama
{
  private DatagramSocket socket=null;
  private DatagramPacket recvPacket, sendPacket;

  public static void main(String[] args)
  {
    DatagramSocket socket=null;
    DatagramPacket recvPacket, sendPacket;
    try
    {
      socket=new DatagramSocket();
      InetAddress hostAddress=InetAddress.getByName("127.0.0.1");
      DataInputStream userData=new DataInputStream(System.in);
      while (socket !=null)
      {
        //leitura da mensagem para enviar para o servidor Datagrama
        System.out.print("Mensagem para enviar: ");
        String userString=userData.readLine();
        if ((userString==null)||(userString.equals("")))
          return;

        //converte o String para um Array de bytes
        byte sendbuf[]=new byte[userString.length()];
        userString.getBytes(0,userString.length(),sendbuf,0);
        sendPacket=new DatagramPacket(sendbuf, sendbuf.length, hostAddress, 4545);

        //envia o Datagrama para o servidor
        socket.send(sendPacket);

        //recebe o Datagrama do servidor
        recvPacket=new DatagramPacket(new byte[512], 512);
        socket.receive(recvPacket);

        //exibe na tela do cliente a mensagem de eco do servidor Datagrama
        System.out.print("Mensagem recebida (eco): ");
        System.out.write(recvPacket.getData(),0,recvPacket.getLength());
        System.out.print("\r\n");
        System.out.print("\r\n");
      }
    }
    catch(SocketException se)
    {
      System.out.println("Erro no ClienteDatagrama: "+se);
    }
    catch(IOException ioe)
    {
      System.out.println("Erro no ClienteDatagrama: "+ioe);
    }
  }
}                                                                                
