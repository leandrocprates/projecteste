import java.io.*;
import java.net.*;

public class ServidorDatagrama
{
  public static void main(String[] args)
  {
    DatagramSocket socket=null;
    DatagramPacket recvPacket, sendPacket;
    try
    {
      System.out.println("=== ��� Servidor de eco no ar !!! ��� ===");
      socket=new DatagramSocket(4545);
      while(socket!=null)
      {
        recvPacket=new DatagramPacket(new byte[512], 512);
        socket.receive(recvPacket);
        sendPacket=new DatagramPacket(
                               recvPacket.getData(), recvPacket.getLength(),
                               recvPacket.getAddress(), recvPacket.getPort());
        socket.send(sendPacket);
        System.out.println("Mensagem recebida do Cliente: "+recvPacket.getAddress()+":"+recvPacket.getPort());
        System.out.print("=> ");
        System.out.write(recvPacket.getData(),0,recvPacket.getLength());
        System.out.print("\r\n");
        System.out.print("\r\n");
      }
    }
    catch(SocketException se)
    {
      System.out.println("Erro no ServidorDatagrama: "+se);
    }
    catch(IOException ioe)
    {
      System.out.println("Erro no ServidorDatagrama: "+ioe);
    }
  }
}
