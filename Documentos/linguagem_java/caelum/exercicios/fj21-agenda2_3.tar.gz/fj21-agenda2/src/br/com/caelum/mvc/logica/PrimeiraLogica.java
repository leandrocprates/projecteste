package br.com.caelum.mvc.logica;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PrimeiraLogica implements Logica {

	public void executa(HttpServletRequest req , HttpServletResponse resp){
		
		System.out.println("Executando a Logica de Redirecinamento");
		RequestDispatcher r = req.getRequestDispatcher("primeira-logica.jsp");
		try {
			r.forward(req, resp);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
