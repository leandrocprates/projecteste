package br.com.caelum.mvc.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.mvc.logica.*;


public class ControllerServlet extends HttpServlet
{

	protected void service (HttpServletRequest req , HttpServletResponse resp){
		String parametro = req.getParameter("logica");
		String nomeDaClasse="br.com.caelum.mvc.logica."+parametro;
		
		try {
			Class classe = Class.forName(nomeDaClasse);
			
			Logica logica = (Logica) classe.newInstance();
			logica.executa(req, resp);
			
		} catch (Exception e) {
			
		}
		
	}
	
}
