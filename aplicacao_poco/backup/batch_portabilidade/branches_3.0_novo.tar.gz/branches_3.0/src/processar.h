
#ifndef PROCCESS
#define PROCCESS

#include "conectar.h"
#include "configuracao.cpp"
#include "obterArquivos.h"
#include <algorithm>
#include <exception>

// separa palavras em tokens
#include "Poco/StringTokenizer.h"
#include "Poco/DateTime.h"

using Poco::StringTokenizer;
using Poco::DateTime;


#define LEN_FILE 50

class processar
{
	public:
		processar(Logger *Log)
		{
			fileLogger = Log ;
		}
		~processar() { }
		
		
		int validar_data(const char *data);
		int processaCabecalho(char *cabecalho);
		int processaTrailler(char *trailler);
		int determinaNumeroOcorrencias(char *detalhe);
		int ehNumero(const char *numero);
		int validaTipoLinha( int tipo_linha );
		int validaTipoPortabilidade(int tipo_portabilidade);
		int validaAcao( int acao );
		int processaRegistro(char dados[]);
		int processarArquivo(string arquivo, string diretorio) ;
		int determinaArquivoSerProcessado( string nomeArquivoListado , string nomeArquivoBD, string diretorio );
		int processamento(conectar *con[] , configuracao *config , string diretorio );

        protected:
                Logger *obterLog ()
                {
                    return fileLogger;
                }

	private:
                
                conectar **conexao;
                configuracao *config;
		Tregistro registro;
		Logger *fileLogger;
		vector<string>  programasListados ; 
		
};

#endif 








