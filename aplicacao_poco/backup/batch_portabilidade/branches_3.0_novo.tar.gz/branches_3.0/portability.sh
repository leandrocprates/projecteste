#!/bin/bash

dir=/home/apptiaxa/portability/arquivos

bash "$dir/script.sh"  $dir 

export  LD_LIBRARY_PATH=/home/apptiaxa/lib/GK

/home/apptiaxa/binn/GK/portability -c portability_in 2>> /tmp/teste_portabilidade.txt

if [ $? -ne 0 ] ; then
     echo "Erro ao executar batch de portabilidade."  >> /tmp/teste_portabilidade.txt 
     exit
fi


