package Utils;


import Model.Autorizacao;
import Model.Livro;
import Model.Usuario;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author José Alexandre
 */
public class HibernateTest {

    public static void main(String[] args) throws SQLException {

        List listaAutorizacao = new ArrayList<Autorizacao>();
        
        Livro livro = new Livro();
        livro.setAutor("clarice Linspector");
        livro.setAvaliacao(2);
        livro.setEditora("Abril");
        livro.setIsbn("85748");
        livro.setPaginas(320);
        livro.setTitulo("Borboletas");
        
        Autorizacao autorizacao = new Autorizacao();
        autorizacao.setNome("ROLE_ADMIN");
        listaAutorizacao.add(autorizacao);
        
        Usuario usuario = new Usuario();
        usuario.setUsername("Leandro");
        usuario.setPassword("okto2647");
        usuario.setEnable(true);
        usuario.setAutorizacoes(listaAutorizacao);
        
        
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction t = session.beginTransaction();
        session.save(livro);
        session.save(autorizacao);
        session.save(usuario);
        
        t.commit();
        System.out.println("ID do Pessoa: " + livro.getId());
        
        //user = (Usuario) session.load(Usuario.class, 1L);
        //System.out.println(user.getNome());

        //session.close();

    }
}
