#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>

#define DATA "The sea is calm tonight, the tide is full . . ."

/*
 * Here I send a datagram to a receiver whose name I get from the command
 * line arguments.  The form of the command line is dgramsend hostname
 * portnumber 
 */

main( int argc, char **argv ){
   int sock;
   struct sockaddr_in name;
   struct hostent *hp;

   int i, max;
   max = atoi(argv[3]);
   char buffer[1024];

      /* Create socket on which to send. */
      sock = socket(AF_INET, SOCK_DGRAM, 0);
      if (sock < 0) {
         perror("opening datagram socket");
         exit(1);
      }
  
      hp = gethostbyname(argv[1]);
      if (hp == 0) {
         fprintf(stderr, "%s: unknown host\n", argv[1]);
         exit(2);
      }
   
      bcopy(hp->h_addr, &name.sin_addr, hp->h_length);
      name.sin_family = AF_INET;
      name.sin_port = htons(atoi(argv[2]));
      /* Send message. */
      
      for (i=0;i<max;i++) {
         
         unsigned int code = i*12000000;
         for (int j=0; j<3; j++) {
            buffer[3-j] = (char) (code & 0xff);
            code >>= 8;
         }
         buffer[0] = (char) code;
         // scanf("%s", buffer);
         strcat (buffer, "DATA SENT");
         if (sendto(sock, buffer, sizeof(buffer), 0,
                    (sockaddr*)&name, sizeof(name)) < 0)
            perror("sending datagram message");
         printf ("Message sent to %s .\n", argv[1]);
      }
   
   close(sock);
}

/* To compile:  gcc -o send send.cc -lsocket -lnsl
 * The command line is: send hostname portnumber 
 */
