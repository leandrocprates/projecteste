#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

main( int argc, char **argv ) {
   int sock, length;
   struct sockaddr_in name;
   char buffer[1024];

   unsigned int buf_bytes[1024];
   
   int i,j, max;
   max = atoi(argv[2]);

   /* Create socket from which to read. */
      sock = socket(AF_INET, SOCK_DGRAM, 0);
      if (sock < 0) {
         perror("opening datagram socket");
         exit(1);
      }
      /* Create name with wildcards. */
      name.sin_family = AF_INET;
      name.sin_addr.s_addr = INADDR_ANY;
      name.sin_port = htons(atoi(argv[1]));
      if (bind(sock, (sockaddr*) &name, sizeof(name))) {
         perror("binding datagram socket");
         exit(1);
      }
      /* Find assigned port value and print it out. */
      printf("Socket has port #%d\n\n", ntohs(name.sin_port));
      length = sizeof(name);
      if (getsockname(sock, (sockaddr*) &name, &length)) {
         perror("getting socket name");
         exit(1);
      }
   
      for (i=0;i<max;i++) {
         /* Read from the socket */
      /*     if (read(sock, buffer, 10240) < 0)
            perror("receiving datagram packet");
         printf("-->%s\n", buffer);
         
         unsigned int code = (unsigned int) (unsigned char) buffer[0];
         for (int j=1; j<4; j++) {
            code <<= 8;
            code += (unsigned int) (unsigned char) buffer[j];
         }
         printf("code==%d",code);
         */
         if (read(sock, buf_bytes, 1024) < 0)
            perror("receiving datagram packet");
            printf("-->\n");
         for (j=0;j<1024;j++) {
            printf("-%d", buf_bytes[j]);
         }
      }
      close(sock);
}

/* compiler gcc -o read read.cc -lsocket -lnsl */
