package br.com.caelum.mvc.logica;

import java.io.IOException;
import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.modelo.*;
import br.com.caelum.agenda.dao.*;

public class RemoveContatoLogic implements Logica {

	public void executa(HttpServletRequest req , HttpServletResponse resp){

		try {
			Contato contato=new Contato();
			long id = Long.parseLong(req.getParameter("id")) ;
			contato.setId(id);
			
			ContatoDAO contatoDao = new ContatoDAO ();
			contatoDao.exclui(contato);
					
			RequestDispatcher r = req.getRequestDispatcher("lista-contatos-elegante.jsp");
			r.forward(req, resp);
			System.out.println("Removendo o Contato ..." + contato.getNome());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
