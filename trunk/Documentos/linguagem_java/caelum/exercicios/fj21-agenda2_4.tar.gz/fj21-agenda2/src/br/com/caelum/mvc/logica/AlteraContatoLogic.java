package br.com.caelum.mvc.logica;

import java.io.IOException;
import java.util.*;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.modelo.*;
import br.com.caelum.agenda.dao.*;



public class AlteraContatoLogic implements Logica {

	public void executa(HttpServletRequest req , HttpServletResponse resp){

		Connection connection=null ; 	
		
		try {
			
			Contato contato=new Contato();
			long id = Long.parseLong(req.getParameter("id")) ;
			contato.setId(id);
			contato.setNome(req.getParameter("nome"));
			contato.setEndereco(req.getParameter("endereco"));
			contato.setEmail(req.getParameter("email"));
			String dataEmTexto= req.getParameter("dataNascimento");
			Date date;

			date = new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
			Calendar dataNascimento = Calendar.getInstance();
			dataNascimento.setTime(date);
			contato.setDataNascimento(dataNascimento);
			
			connection = (Connection ) req.getAttribute("connection");
			
			ContatoDAO contatoDao = new ContatoDAO (connection);
			contatoDao.atualiza(contato);
					
			RequestDispatcher r = req.getRequestDispatcher("lista-contatos-elegante.jsp");
			r.forward(req, resp);
			System.out.println("Alterando o Contato ..." + contato.getNome());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
