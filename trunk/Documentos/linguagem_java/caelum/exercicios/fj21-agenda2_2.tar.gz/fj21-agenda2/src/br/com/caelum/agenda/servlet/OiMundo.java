
package br.com.caelum.agenda.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class OiMundo extends HttpServlet 
{
	public void init(ServletConfig config) throws ServletException{
		super.init(config);
		log("Iniciando a servlet");
	}
	
	protected void service(HttpServletRequest  req , HttpServletResponse resp ){
		try {
			PrintWriter out = resp.getWriter();
			out.println("<html>");
			out.println("<head>");
			out.println("</head>");
			out.println("<body>");
			out.println(new Date());
			out.println("</body>");
			out.println("</html>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void destroy(){
		super.destroy();
		log("Destruindo a servlet");
	}

}
