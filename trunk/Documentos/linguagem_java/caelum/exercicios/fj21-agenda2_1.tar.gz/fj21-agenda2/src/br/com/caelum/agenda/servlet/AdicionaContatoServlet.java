package br.com.caelum.agenda.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.agenda.dao.ContatoDAO;
import br.com.caelum.agenda.modelo.Contato;

public class AdicionaContatoServlet extends HttpServlet
{
	
	protected void service (HttpServletRequest req , HttpServletResponse resp){
		
		try {
			PrintWriter out = resp.getWriter();
			
			String nome = req.getParameter("nome");
			String endereco = req.getParameter("endereco");
			String email = req.getParameter("email");
			String dataemTexto = req.getParameter("dataNascimento");
			Calendar dataNascimento =null; 
			
			try {
				Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dataemTexto);
				dataNascimento = Calendar.getInstance();
				dataNascimento.setTime(date);
				
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			Contato contato = new Contato();
			contato.setNome(nome);
			contato.setEmail(email);
			contato.setEndereco(endereco);
			contato.setDataNascimento(dataNascimento);
			
			ContatoDAO dao = new ContatoDAO();
			dao.adiciona(contato);
			out.println("<html>");
			out.println("<body>");
			out.println("Contato "+contato.getNome()+" adicionado com sucesso.");
			out.println("</body>");
			out.println("</html>");
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
