
package br.com.caelum.tarefas.action;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;

public class OlaMundoAction {

	// pode ser adicionada diversas anotacoes para dependendo da resposta
	// chamar o jsp correto
	@Action(value="olaMundoStruts", 
			results={ @Result( location="/olaMundoStruts.jsp" , name="ok" ) , 
					  @Result( location="/olaTesteStruts.jsp" , name="nok" )
			} )
	       
	public String execute(){
		System.out.println("Executando a logica com Structs2");
		return "ok" ; 
	}
	
}
