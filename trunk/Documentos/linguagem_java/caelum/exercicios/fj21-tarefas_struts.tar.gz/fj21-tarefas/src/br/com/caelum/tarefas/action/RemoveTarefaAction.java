package br.com.caelum.tarefas.action;



import br.com.caelum.tarefas.dao.TarefaDAO;
import br.com.caelum.tarefas.modelo.*;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Actions;
import org.apache.struts2.convention.annotation.Result;



public class RemoveTarefaAction {

	private Tarefa tarefa;
	
	@Action(value="removeTarefa", results={ @Result(name="ok",type="redirectAction",params={"actionName","listaTarefas"} ) } )
	
	public String execute(){
		new TarefaDAO().remove(tarefa);
		return "ok";
	}
	
	public void setTarefa(Tarefa tarefa){
		this.tarefa=tarefa;
		
	}
	
	public Tarefa getTarefa(){
		return this.tarefa;
	}
	
	
}
