package br.com.caelum.hibernate;

import java.util.GregorianCalendar;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Teste1 {
	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();

		Produto p = new Produto(); // Objeto Transiente
		p.setNome("Bola");
		p.setPreco(300);
		
		Transaction t = s.beginTransaction();
		s.save(p);  // Objeto persistente
		t.commit();
		
		p.setNome("caderno");
		
		Transaction t2 = s.beginTransaction();
		t2.commit();
		
	}

}




