package br.com.caelum.hibernate;

import java.util.GregorianCalendar;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Teste3 {
	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();

		Produto p = (Produto) s.load(Produto.class, 1L); // Retorna Objeto Persistente

		System.out.println("Nome: "+p.getNome());
		
		//s.evict(p); // Object Detached
		s.clear();    // Object Detached 
		s.update(p);  // Volta o Objeto para o estado Persistente 
		
		p.setNome("Produto 50");
		
		//Transaction t2 = s.beginTransaction();
		//t2.commit();
		s.flush(); // serve como commit para banco sem transacao MYSAM
		
		System.out.println("Nome: "+p.getNome());
	}
}

