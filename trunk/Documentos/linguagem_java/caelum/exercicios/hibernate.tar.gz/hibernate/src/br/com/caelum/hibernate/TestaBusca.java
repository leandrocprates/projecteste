package br.com.caelum.hibernate;

import java.util.GregorianCalendar;
import org.hibernate.Session;

public class TestaBusca {

	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();
		ProdutoDAO dao = new ProdutoDAO(s);

		System.out.println("********** Listando Tudo **********") ;
		
		for ( Produto p : dao.listaTudo()){
			System.out.println(p.getNome());
		}

		System.out.println("********** Listando Paginado **********") ;		
		for ( Produto p : dao.pagina(2, 3)){
			System.out.println(p.getNome());
		}

		System.out.println("********** Precos Maiores **********") ;		
		for ( Produto p : dao.precoMaiorQue(100)){
			System.out.println(p.getNome());
		}
		s.close();
	}
}
