package br.com.caelum.hibernate;

import java.util.GregorianCalendar;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Teste5 {
	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();

		Produto p = (Produto) s.load(Produto.class, 1L); // Retorna Objeto Persistente

		Produto z = (Produto) s.get(Produto.class, 1L); // Retorna Objeto Persistente
		
		System.out.println("xxxxxxx");
		
		System.out.println("Nome"+p.getNome());
	}

}




