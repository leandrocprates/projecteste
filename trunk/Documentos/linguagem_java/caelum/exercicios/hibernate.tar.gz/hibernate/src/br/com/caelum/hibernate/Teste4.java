package br.com.caelum.hibernate;

import java.util.GregorianCalendar;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Teste4 {
	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();

		//Query query = s.createQuery("select p from Produto p where p.preco >= 100 ");
		//List<Produto> produto = query.list();

		Criteria c = s.createCriteria(Produto.class);
		List<Produto> produto = c.list();	
		
		 for (Produto p : produto ) {
			 System.out.println("Id : " +p.getId());
			 System.out.println("Nome : " +p.getNome());
			 System.out.println("Preco : " +p.getPreco());
		 }
	}
}

