package br.com.caelum.hibernate;


import java.util.GregorianCalendar;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Teste2 {
	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();

		Produto p = (Produto) s.load(Produto.class, 1L); // Retorna Objeto Persistente

		System.out.println("Nome: "+p.getNome());
		
		p.setNome("Produto 30");
		
		Transaction t2 = s.beginTransaction();
		t2.commit();
		
	}

}




