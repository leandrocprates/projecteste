package br.com.caelum.hibernate;

import java.util.GregorianCalendar;

import org.hibernate.Session;

public class TestaProdutoDAO {

	public static void main(String args[]){

		Session s = new HibernateUtil().getSession();
		ProdutoDAO dao = new ProdutoDAO(s);

		Produto p = new Produto();
		p.setNome("Testando 1 ");
		p.setDataInicioVenda(new GregorianCalendar(2010,1,26));
		p.setPreco(200);
		
		dao.salva(p);
		s.close();
		
	}
}
