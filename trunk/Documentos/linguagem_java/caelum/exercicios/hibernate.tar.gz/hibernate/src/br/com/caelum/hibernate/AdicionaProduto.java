package br.com.caelum.hibernate;

import java.util.GregorianCalendar;

import org.hibernate.Session;

public class AdicionaProduto {

	public static void main(String args[]){
		Produto p = new Produto();
		p.setNome("Produto 2 " ) ; 
		p.setPreco(100);
		p.setDataInicioVenda(new GregorianCalendar(2010,1,26));
		
		Session s = new HibernateUtil().getSession();
		s.save(p);
		s.close();
		System.out.println("Id do Produto Inserido : " + p.getId());
		//s.close();
		
	}
	
	
}
