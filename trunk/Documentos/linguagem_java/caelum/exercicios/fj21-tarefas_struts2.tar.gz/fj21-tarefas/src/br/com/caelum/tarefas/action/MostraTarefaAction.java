package br.com.caelum.tarefas.action;



import br.com.caelum.tarefas.dao.TarefaDAO;
import br.com.caelum.tarefas.modelo.*;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Actions;
import org.apache.struts2.convention.annotation.Result;



public class MostraTarefaAction {

	private Tarefa tarefa;
	private Long id;
	
	@Action(value="mostraTarefa", results={ @Result(name="ok",location="/mostra-tarefa.jsp") } )
	
	public String execute(){
		tarefa = new TarefaDAO().buscaPorId(id);
		return "ok";
	}
	
	public void setTarefa(Tarefa tarefa){
		this.tarefa=tarefa;
		
	}
	
	public Tarefa getTarefa(){
		return this.tarefa;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
}
