#ifndef UTIL_H
#define UTIL_H

class QMainWindow;
class QKeyEvent;
class QSqlQuery;
class QSqlQueryModel;
class QString;
class QTableView;
class QWidget;
class QAction;
class QDesktopWidget;
class QRect;
class QStringList;
class QLineEdit;
class QLabel;
class QCloseEvent;

/**
@author Rodolfo Ribeiro Machado,,,
*/
class util
{
  public:
    util();
    ~util();
    
    void fixa_Tamanho(QWidget* comp);
    void centraliza_na_Tela(QWidget* comp);
    QString lanca_Aplicativo(QString aplicativo,QString argumento,QWidget* comp);

};

#endif
