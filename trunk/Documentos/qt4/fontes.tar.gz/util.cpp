#include "util.h"
#include <QDesktopWidget>
#include <QProcess>


util::util()
{
}


util::~util()
{
}



void util::fixa_Tamanho(QWidget* comp)
{
  QSize* tamanho=new QSize();
  *tamanho=comp->size();
  comp->setFixedSize (*tamanho);
  delete tamanho;
}

void util::centraliza_na_Tela(QWidget* comp)
{
  QSize* tamanho=new QSize();
  *tamanho=comp->size();
  QDesktopWidget* desk=new QDesktopWidget();
  QRect rect=desk->screenGeometry(0);
    
  int * x1=new int;
  int * y1=new int;
  int * x2=new int; 
  int * y2=new int;
  rect.getCoords(x1,y1,x2,y2);
    
  comp->setGeometry((*x2-tamanho-> width ())/2,(*y2-tamanho-> height ())/2,tamanho-> width (),tamanho-> height ());
  delete tamanho;
  delete x1;
  delete x2;
  delete y1;
  delete y2;
  delete desk;
}

/*void centralizarWidget(QWidget *widget)
{
QRect rect = QApplication::desktop()->availableGeometry(widget);

widget->move(rect.center() - widget->rect().center());
}*/

QString util::lanca_Aplicativo(QString aplicativo,QString argumento,QWidget* comp)
{
  QStringList argumento_2;
  argumento_2<<argumento;
  QProcess *myProcess = new QProcess(comp);

  myProcess->start(aplicativo, argumento_2);
  myProcess->waitForFinished();
  
  return myProcess->readAllStandardOutput();
  
}

